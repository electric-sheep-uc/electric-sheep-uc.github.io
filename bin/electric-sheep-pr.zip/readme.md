# Electric Sheep PR Package

Last updated: `2018-06-09`

The following is intended for external media wanting to write an accurate
article regarding the team. We recommend that you reach out to us prior to
publishing in order for us to provide up-to-date information and media as well
as offering to ensure the technical accuracy of the article.

The information and media offered in this package are free to use in articles.
If there sis something missing or incorrect, please contact us so that we may
correct it.

You can contact us via email: `electric-sheep-rc@googlegroups.com`

## Identification

### Name

The name of the team is "Electric Sheep", two words capitalised for the first
letters. The name refers to the book: *Do Androids Dream of Electric Sheep* (by
Philip K Dick, written in 1968), the film: *Blade Runner: Do Androids Dream of
Electric Sheep* (1982) and the University of Canterbury's coat of arms -
specifically to New Zealand's background in pastoralism.

### Members

#### Core Team

* **Daniel Barry** An experienced member of a RoboCup team in the UK (Bold
Hearts), which achieved second place in the world cup within two years.
Currently he is working on his PhD on cooperative UAV search behaviours at UC.

* **Munir Shah** Out-of-uni industry data scientist, the team’s vision
specialist. His work specifically involves computer vision, image processing
and machine learning in a football domain.

* **Andrew Curtis-Black** UC engineering PhD student, specializing in
software-defined networking, with a background in AI and machine learning.

* **Merel Keijsers** The only team member with a social science background, she
plans to bridge the gap in order for humans and robots to safely play
competitively. She currently researches robot bullying as part of her PhD at
the HitLab, UC.

* **Matt Young** UC PhD in Mechatronics Engineering, where he is focusing on
the area of mobile robotics product design.

* **Hussain Syed Kazmi** A visiting PhD student from the university of Leuven
(KU Leuven) who has joined our team on a temporary basis. In his PhD he is
designing a sensory robot that can autonomously roam around specified areas of
a building to take measurements on air quality and room occupancy.

#### Support Staff

Associate Professor **Christoph Bartneck**, HITlab NZ, HRI researcher.

Associate Professor **Richard Green**, with research in vision.

Dr **Simon Hoermann**, HITlab NZ, HRI researcher.

Dr **Graeme Woodward**, with research in wireless communications.

### Images

The logo is of a "digitized" sheep, blue to represent "electric" - reiterating
the team's name.

The following are images that can be used to identify the team:

* `logo.png` - A large bitmap logo.
* `logo.svg` - A scalar logo.

For images that can be used in articles, please see the `images` directory. For
other images, please contact us.

## Background

### Biography

The following can be used to describe out team, it is recommended that this is
transformed to prevent overlap with other existing articles:

The team was first realized in December 2017 when we awarded initial funding
from the University of Canterbury's Engineering School, to build three robots
and to provide demos of the robots at venues and open days.

We are a small but dedicated team of robot enthusiasts from multiple
disciplines, including networking, computer vision, data science, artificial
intelligence and psychology. As a RoboCup team we want to tackle several unique
goals: an open & affordable humanoid platform, system adaptability and real
time environment response.

### Goal

RoboCup poses the following mission statement:

>By the middle of the 21st century, a team of fully autonomous humanoid robot
>soccer players shall win a soccer game, complying with the official rules of
>FIFA, against the winner of the most recent World Cup.

Put simply, the idea is that the best robot football team will play against the
best human football team with equal advantage - and the robot team should win.
This challenge posed to anyone who dare take it involves major advances in
technology, from low level hardware to high level software - all working
together in a yet unseen real-time robotics system.
